package com.demojunie.product;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ProductValidationTest {

    private static Validator validator;

    @BeforeAll
    static void setupValidator() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void validProduct_shouldHaveNoViolations() {
        Product p = new Product("Clavier", new BigDecimal("10.00"), 3);
        Set<ConstraintViolation<Product>> violations = validator.validate(p);
        assertTrue(violations.isEmpty(), "Expected no validation violations: " + violations);
    }

    @Test
    void blankName_shouldTriggerViolation() {
        Product p = new Product("  ", new BigDecimal("10.00"), 3);
        Set<ConstraintViolation<Product>> violations = validator.validate(p);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("name")));
    }

    @Test
    void negativePrice_shouldTriggerViolation() {
        Product p = new Product("P1", new BigDecimal("-1.00"), 3);
        Set<ConstraintViolation<Product>> violations = validator.validate(p);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("price")));
    }

    @Test
    void tooManyFractionDigits_shouldTriggerDigitsViolation() {
        Product p = new Product("P1", new BigDecimal("1.234"), 3);
        Set<ConstraintViolation<Product>> violations = validator.validate(p);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("price")));
    }

    @Test
    void negativeQuantity_shouldTriggerViolation() {
        Product p = new Product("P1", new BigDecimal("1.20"), -1);
        Set<ConstraintViolation<Product>> violations = validator.validate(p);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("quantity")));
    }
}
