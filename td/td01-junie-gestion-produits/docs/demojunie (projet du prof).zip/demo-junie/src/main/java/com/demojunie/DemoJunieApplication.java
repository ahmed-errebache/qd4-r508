package com.demojunie;

import com.demojunie.product.Product;
import com.demojunie.product.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;

@SpringBootApplication
public class DemoJunieApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoJunieApplication.class, args);
    }

    @Bean
    CommandLineRunner loadData(ProductRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.save(new Product("Clavier", new BigDecimal("29.99"), 100));
                repo.save(new Product("Souris", new BigDecimal("19.50"), 200));
                repo.save(new Product("Écran", new BigDecimal("199.00"), 50));
            }
        };
    }
}
