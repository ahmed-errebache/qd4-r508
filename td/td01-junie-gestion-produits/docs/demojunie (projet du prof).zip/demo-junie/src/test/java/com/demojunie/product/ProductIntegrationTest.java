package com.demojunie.product;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Transactional
class ProductIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ProductRepository productRepository;

    @BeforeEach
    void clean() {
        // Assurer l'isolement entre tests
        productRepository.deleteAll();
    }

    @Test
    void fullCrudFlow_shouldWorkThroughHttpAndPersistence() throws Exception {
        // 1) Liste vide au départ
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("MonProd"))));

        // 2) Création
        mockMvc.perform(post("/products")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("name", "MonProd")
                        .param("price", "12.50")
                        .param("quantity", "4"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));

        // 3) Présent dans la liste
        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("MonProd")));

        // 4) Récupérer l'id puis modifier
        Long id = productRepository.findByNameContainingIgnoreCase("MonProd").getFirst().getId();

        mockMvc.perform(post("/products/update")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("id", String.valueOf(id))
                        .param("name", "MonProd2")
                        .param("price", "15.00")
                        .param("quantity", "6"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("MonProd2")));

        // 5) Supprimer
        mockMvc.perform(post("/products/delete/" + id))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("MonProd2"))));
    }
}
