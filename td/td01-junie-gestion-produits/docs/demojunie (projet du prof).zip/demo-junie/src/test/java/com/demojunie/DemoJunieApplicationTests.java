package com.demojunie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJunieApplicationTests {

    @Test
    void contextLoads() {
    }

}
