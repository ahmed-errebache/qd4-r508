package com.demojunie.product;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@DataJpaTest
class ProductRepositoryTest {

    @Autowired
    private ProductRepository repository;

    @BeforeEach
    void setUp() {
        // Nettoyer les données existantes avant chaque test
        repository.deleteAll();
    }

    @Test
    void saveFindDelete_flow() {
        Product p = new Product("TestProd", new BigDecimal("12.34"), 7);
        Product saved = repository.save(p);
        Assertions.assertNotNull(saved.getId());

        Optional<Product> byId = repository.findById(saved.getId());
        Assertions.assertTrue(byId.isPresent());
        Assertions.assertEquals("TestProd", byId.get().getName());

        repository.deleteById(saved.getId());
        Assertions.assertFalse(repository.findById(saved.getId()).isPresent());
    }

    @Test
    void findByNameContainingIgnoreCase_shouldWork() {
        repository.save(new Product("Souris Gaming", new BigDecimal("20.00"), 10));
        repository.save(new Product("Tapis de souris", new BigDecimal("5.00"), 50));
        repository.save(new Product("Clavier", new BigDecimal("30.00"), 5));

        List<Product> res1 = repository.findByNameContainingIgnoreCase("SOURIS");
        Assertions.assertEquals(2, res1.size());

        List<Product> res2 = repository.findByNameContainingIgnoreCase("clav");
        Assertions.assertEquals(1, res2.size());
        Assertions.assertTrue(res2.stream().anyMatch(p -> "Clavier".equals(p.getName())));
    }
}
