package com.demojunie.product;

import com.demojunie.DemoJunieApplication;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes = DemoJunieApplication.class)
class ProductDataSeedIntegrationTest {

    @Autowired
    ProductRepository productRepository;

    @Test
    void seedData_shouldBeAvailableOnStartup() {
        // Le CommandLineRunner insère 3 produits si le repo est vide
        long count = productRepository.count();
        assertTrue(count >= 3, "Expected at least 3 seed products but got " + count);
    }
}
