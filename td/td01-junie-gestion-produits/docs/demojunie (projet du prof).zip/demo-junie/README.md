# demo-junie

Application Spring Boot de gestion de produits (id, name, price, quantity) avec Spring Data JPA, H2 Database et Thymeleaf.

## Fonctionnalités
- Lister les produits avec recherche par nom (insensible à la casse)
- Créer, modifier, supprimer un produit
- Validation côté serveur (nom obligatoire, prix >= 0 avec 2 décimales, quantité >= 0)
- Données d’exemple insérées au démarrage (Clavier, Souris, Écran)

## Pile technique
- Java 21
- Spring Boot 3 (Web, Thymeleaf, Spring Data JPA)
- H2 Database (en mémoire)
- Hibernate Validator
- Maven

## Prérequis
- JDK 21
- Maven 3.9+ (ou wrapper Maven fourni: `mvnw`/`mvnw.cmd`)

## Lancer l’application
Port par défaut: `8084`.

- Avec Maven (recommandé en dev):
  ```bash
  ./mvnw spring-boot:run    # Linux/macOS
  mvnw.cmd spring-boot:run  # Windows
  ```
- Ou construire puis exécuter le JAR:
  ```bash
  ./mvnw -q clean package
  java -jar target/demo-junie-0.0.1-SNAPSHOT.jar
  ```

## URLs principales
- Application (liste des produits): http://localhost:8084/products
- Redirection racine → produits: http://localhost:8084/
- Console H2: http://localhost:8084/h2-console
  - JDBC URL: `jdbc:h2:mem:productsdb`
  - User: `sa`, Mot de passe: (vide)

## Utilisation
1. Ouvrir http://localhost:8084/products
2. Créer un produit via « Nouveau »
3. Modifier/Supprimer via les actions de la liste
4. Rechercher par nom via le champ « Rechercher par nom »

Les gabarits Thymeleaf se trouvent dans `src/main/resources/templates`:
- `products.html`: liste + recherche
- `product-form.html`: création/édition

## Configuration
Paramètres principaux (fichier `src/main/resources/application.properties`):
- `server.port=8084`: port HTTP
- `spring.h2.console.enabled=true`, `spring.h2.console.path=/h2-console`
- Datasource H2 en mémoire: `spring.datasource.url=jdbc:h2:mem:productsdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE`
- JPA/Hibernate: `spring.jpa.hibernate.ddl-auto=update`, `spring.jpa.show-sql=true`

## Structure du projet
```
.
├─ pom.xml
├─ src/main/java/com/demojunie
│  ├─ DemoJunieApplication.java        # Bootstrap + chargement de données
│  ├─ WebConfig.java                   # Redirection / → /products
│  └─ product
│     ├─ Product.java                  # Entité JPA
│     ├─ ProductRepository.java        # Spring Data JPA
│     └─ ProductController.java        # Contrôleur MVC
├─ src/main/resources
│  ├─ application.properties           # Configuration
│  └─ templates
│     ├─ products.html
│     └─ product-form.html
└─ src/test/java/com/demojunie
   └─ DemoJunieApplicationTests.java
```

## Tests
- Lancer tous les tests: `mvnw.cmd -q -e test` (Windows) ou `./mvnw -q -e test` (Linux/macOS)
- Types de tests inclus:
  - Validation de l’entité Product (sans contexte Spring)
  - Tests JPA du repository (@DataJpaTest)
  - Tests MVC du contrôleur (@WebMvcTest + MockMvc)
  - Tests d’intégration Spring Boot (contexte complet + H2 + Thymeleaf) avec MockMvc: ProductIntegrationTest
  - Test d’intégration de données seed au démarrage: ProductDataSeedIntegrationTest
- Remarque: les tests JPA/MVC/Intégration téléchargent des dépendances de test au premier lancement. Si votre environnement n’a pas accès au réseau ou utilise un proxy, vous pourriez voir des erreurs de « artifact resolution ». Dans un environnement Maven standard avec accès aux dépôts, les tests passent normalement.

### Rapport de couverture (JaCoCo)
- Génération automatique pendant `mvn test`.
- Rapport HTML: ouvrir `target\site\jacoco\index.html`.
- Fichier XML (CI/Coverage badge): `target\site\jacoco\jacoco.xml`.

## Dépannage
- Port déjà utilisé: changez `server.port` dans `application.properties` (ex: 8085) ou libérez le port 8084.
- Erreur de build JDK: assurez-vous d’utiliser Java 21 (`java -version`).
- Console H2 inaccessible: vérifiez `spring.h2.console.enabled=true` et l’URL `/h2-console`.

## Licence
Ce projet est fourni à des fins d’exemple pédagogique. Ajoutez votre licence si nécessaire.


## Publication sur GitHub
Voici comment créer un dépôt GitHub sur votre compte « ocaspary » et y pousser ce projet.

Prérequis:
- Avoir un compte GitHub (utilisateur: ocaspary) et être connecté.
- Git installé en local.

Étape A — Créer le dépôt sur GitHub (interface web):
1) Aller sur https://github.com/new
2) Owner: sélectionner « ocaspary »
3) Repository name: « demo-junie »
4) Choisir public ou private selon votre préférence
5) Ne cochez pas « Add a README » (déjà présent) ni .gitignore (déjà ajouté)
6) Cliquer sur « Create repository »

Étape B — Pousser le code local vers GitHub (dans ce dossier):
```bash
# Initialiser le dépôt (si pas déjà un repo git)
git init

# Ajouter tous les fichiers et faire un commit initial
git add .
git commit -m "Initial import"

# Créer/forcer la branche principale
git branch -M main

# Ajouter la cible distante vers votre dépôt GitHub
git remote add origin https://github.com/ocaspary/demo-junie.git

# Envoyer la branche principale
git push -u origin main
```

Option alternative via GitHub CLI (si installée):
```bash
# Crée le repo sous ocaspary, le relie au dossier courant et pousse le code
gh repo create ocaspary/demo-junie --source=. --remote=origin --private --push
# (remplacez --private par --public si souhaité)
```

Intégration Continue (CI):
- Le workflow GitHub Actions est déjà configuré (.github/workflows/ci.yml).
- À chaque push/PR, la CI lancera: build Maven + tests + génération et upload du rapport JaCoCo (artefacts téléchargeables depuis l’onglet « Actions » du dépôt).

Astuce (optionnel) — Renseigner l’URL SCM dans le pom.xml:
- Une fois le dépôt créé, vous pouvez mettre à jour la section <scm> du pom.xml:
```xml
<scm>
  <url>https://github.com/ocaspary/demo-junie</url>
  <connection>scm:git:https://github.com/ocaspary/demo-junie.git</connection>
  <developerConnection>scm:git:ssh://git@github.com/ocaspary/demo-junie.git</developerConnection>
  <tag>main</tag>
</scm>
```
