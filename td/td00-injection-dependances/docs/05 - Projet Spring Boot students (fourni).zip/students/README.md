# Demo DI Spring Boot

## Lancer

```bash
mvn spring-boot:run
```

## Tester

```bash
curl -X POST "http://localhost:8080/students/add?name=Paul"
```

## Structure:

* `StudentsApplication.java`
* `controller/StudentController.java`
* `service/StudentService.java`
* `repository/StudentRepository.java`, `StudentRepositoryImpl.java`
* `resources/application.properties`
