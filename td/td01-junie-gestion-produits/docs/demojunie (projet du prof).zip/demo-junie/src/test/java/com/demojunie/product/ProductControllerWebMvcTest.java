package com.demojunie.product;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SuppressWarnings("removal")
@WebMvcTest(ProductController.class)
class ProductControllerWebMvcTest {

    @Autowired
    private MockMvc mockMvc;

    @SuppressWarnings("removal")
    @MockBean
    private ProductRepository productRepository;

    @Test
    @DisplayName("GET /products shows list and forwards to products view")
    void list_noKeyword() throws Exception {
        List<Product> products = Arrays.asList(
                new Product("A", new BigDecimal("1.00"), 1),
                new Product("B", new BigDecimal("2.00"), 2)
        );
        given(productRepository.findAll()).willReturn(products);

        mockMvc.perform(get("/products"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"))
                .andExpect(model().attributeExists("products"))
                .andExpect(model().attribute("keyword", (Object) null));
    }

    @Test
    @DisplayName("GET /products?keyword=abc calls repository search and shows view")
    void list_withKeyword() throws Exception {
        given(productRepository.findByNameContainingIgnoreCase("abc")).willReturn(List.of());

        mockMvc.perform(get("/products").param("keyword", "abc"))
                .andExpect(status().isOk())
                .andExpect(view().name("products"))
                .andExpect(model().attributeExists("products"))
                .andExpect(model().attribute("keyword", "abc"));
    }

    @Test
    void create_valid_shouldRedirect() throws Exception {
        given(productRepository.save(ArgumentMatchers.any(Product.class))).willAnswer(inv -> inv.<Product>getArgument(0));

        mockMvc.perform(post("/products")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("name", "Clavier")
                        .param("price", "10.00")
                        .param("quantity", "5"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));

        verify(productRepository).save(ArgumentMatchers.any(Product.class));
    }

    @Test
    void create_invalid_shouldReturnForm() throws Exception {
        mockMvc.perform(post("/products")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("name", "") // invalid blank name
                        .param("price", "-1") // invalid
                        .param("quantity", "-2")) // invalid
                .andExpect(status().isOk())
                .andExpect(view().name("product-form"))
                .andExpect(model().attributeHasFieldErrors("product", "name", "price", "quantity"));
    }

    @Test
    void editForm_shouldLoadProduct() throws Exception {
        Product p = new Product("A", new BigDecimal("1.00"), 1);
        p.setId(123L);
        given(productRepository.findById(123L)).willReturn(Optional.of(p));

        mockMvc.perform(get("/products/edit/{id}", 123L))
                .andExpect(status().isOk())
                .andExpect(view().name("product-form"))
                .andExpect(model().attributeExists("product"))
                .andExpect(model().attribute("action", "/products/update"));
    }

    @Test
    void update_invalid_shouldReturnForm() throws Exception {
        mockMvc.perform(post("/products/update")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("id", "1")
                        .param("name", "")
                        .param("price", "-1")
                        .param("quantity", "-1"))
                .andExpect(status().isOk())
                .andExpect(view().name("product-form"))
                .andExpect(model().attributeHasFieldErrors("product", "name", "price", "quantity"));
    }

    @Test
    void update_valid_shouldRedirect() throws Exception {
        given(productRepository.save(ArgumentMatchers.any(Product.class))).willAnswer(inv -> inv.getArgument(0));

        mockMvc.perform(post("/products/update")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .param("id", "1")
                        .param("name", "C")
                        .param("price", "9.99")
                        .param("quantity", "3"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));
    }

    @Test
    void delete_shouldRedirect() throws Exception {
        mockMvc.perform(post("/products/delete/{id}", 5L))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/products"));

        verify(productRepository).deleteById(5L);
    }
}
